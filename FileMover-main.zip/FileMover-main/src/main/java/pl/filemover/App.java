package pl.filemover;

import pl.filemover.ui.FileSelectorWindow;

public class App 
{
    public static void main( String[] args )
    {
    	new FileSelectorWindow();
    }
}
