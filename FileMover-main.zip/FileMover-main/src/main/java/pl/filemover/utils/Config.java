package pl.filemover.utils;

public class Config {
	public static final int THREAD_COUNT = 10;
	public static final int BUFFER_SIZE = 32 * 1024; // 32 KB
}
