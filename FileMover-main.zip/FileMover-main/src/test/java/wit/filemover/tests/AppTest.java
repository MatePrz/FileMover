package wit.filemover.tests;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
}
